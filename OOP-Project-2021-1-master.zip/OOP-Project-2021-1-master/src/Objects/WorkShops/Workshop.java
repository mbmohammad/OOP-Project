package Objects.WorkShops;

import Functions.Random_Location;
import Functions.Variable_Reading;

import java.io.FileNotFoundException;

public class Workshop {
    protected int level;
    protected int needed_time;
    protected int upgrade_cost;

    public int getLevel() {
        return level;
    }
}
