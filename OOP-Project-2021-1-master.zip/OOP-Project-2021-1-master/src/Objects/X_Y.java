package Objects;

public class X_Y {
    int x;
    int y;

    public X_Y(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
